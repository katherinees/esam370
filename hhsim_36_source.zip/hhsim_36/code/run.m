function run

disp('please type ''hhsim'' instead');
hhsim
