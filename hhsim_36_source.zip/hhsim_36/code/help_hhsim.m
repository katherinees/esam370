function help_hhsim
openurl('help/guide.html');
